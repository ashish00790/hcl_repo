import pymysql
import sys

REGION = 'us-east-2b'

rds_host  = "hcl-usecase.ckqip1nhihss.us-east-2.rds.amazonaws.com"
name = "hcl_admin"
password = "Password1"
db_name = "hcl_db"

def save_events(event):
    """
    This function fetches content from mysql RDS instance
    """
    result = []
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    with conn.cursor() as cur:
        cur.execute("""insert into test_tb (id, name) values( %s, '%s')""" % (event['id'], event['name']))
        cur.execute("""select * from test_tb""")
        conn.commit()
        cur.close()
        for row in cur:
            result.append(list(row))
        print("data from table")
        print(result)

def main(event, context):
    save_events(event)